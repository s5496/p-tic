import React, {Component} from 'react';
import Ui from "../Ui/Ui";

class Game extends Component {
    render() {
        return (
            <Ui size = {3}/>
        )
    }
}

export default Game;