import React, { Component } from 'react';
import Game from './components/Game/Game';

class App extends Component {
  render() {
    return (
      <Game/>
    );
  }
}

export default App;
